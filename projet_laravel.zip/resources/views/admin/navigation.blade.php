<ul class="nav">
    <li class="nav-item">
        <a class="nav-link" href="{{ route('admin.dashboard') }}">Dashboard</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="{{ route('admin.pages.index') }}">Pages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="{{ route('admin.changelog') }}">Changelog</a>
    </li>
</ul>