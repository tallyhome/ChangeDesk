<?php $__env->startSection('title', 'Gestion du Changelog'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Gestion des Versions</h1>
            <?php if(Route::has('admin.changelog.create')): ?>
                <a href="<?php echo e(route('admin.changelog.create')); ?>" class="btn btn-success mb-3">Nouvelle Version</a>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Version</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $versions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($version->version_number); ?></td>
                            <td><?php echo e($version->release_date->format('d/m/Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.changelog.edit', $version->id)); ?>" class="btn btn-sm btn-primary">Modifier</a>
                                <form action="<?php echo e(route('admin.changelog.destroy', $version->id)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Confirmer la suppression ?')">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Adev\200  -  test\projet_laravel\resources\views/admin/changelog/index.blade.php ENDPATH**/ ?>