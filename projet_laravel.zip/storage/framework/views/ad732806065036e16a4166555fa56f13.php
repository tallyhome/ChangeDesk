<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> - MyVcard MyPredict</title>

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar-dark .navbar-nav .nav-link {
            color: rgba(255, 255, 255, 0.9);
            background-color: transparent !important;
            box-shadow: none !important;
            outline: none !important;
            padding: 8px 15px;
            margin: 0 2px;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        .navbar-dark .navbar-nav .nav-link:hover {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.1) !important;
            transform: translateY(-2px);
        }
        .navbar-dark .navbar-nav .nav-link.active {
            font-weight: bold;
            color: #fff;
            background-color: rgba(255, 255, 255, 0.15) !important;
            box-shadow: none !important;
            outline: none !important;
        }
        .navbar-dark .navbar-nav .nav-link:focus {
            color: #fff;
            background-color: transparent !important;
            box-shadow: none !important;
            outline: none !important;
        }
        .navbar-dark .navbar-nav .nav-link:active {
            background-color: rgba(255, 255, 255, 0.2) !important;
            transform: translateY(0);
            box-shadow: none !important;
            outline: none !important;
        }
        
        /* Style pour un pied de page plus compact et toujours en bas */
        html, body {
            height: 100%;
            margin: 0;
        }
        
        #app {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        main {
            flex: 1;
        }
        
        footer {
            padding: 0.5rem 0 !important;
            background-color: #f8f9fa !important;
            font-size: 0.85rem;
        }

        /* Style pour le menu déroulant Admin */
        .dropdown-menu {
            z-index: 1050 !important;
            position: absolute !important;
        }
    </style>
    <?php echo $__env->yieldContent('head'); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <div id="app">
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">MyVcard MyPredict ChanLog</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('changelog') ? 'active' : ''); ?>" href="<?php echo e(route('changelog')); ?>">Changelog</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('todolist') ? 'active' : ''); ?>" href="<?php echo e(route('todolist')); ?>">Prochaines fonctionnalités</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('bug-report') ? 'active' : ''); ?>" href="<?php echo e(route('bug-report')); ?>">Signaler un bug</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Admin
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="adminDropdown">
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.pages.index')); ?>">Pages</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.changelog')); ?>">Changelog</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.todolist')); ?>">Prochaines fonctionnalités</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.bug_reports')); ?>">Rapports de bugs</a></li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-link nav-link">Déconnexion</button>
                                </form>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>">Connexion</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <footer>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0">&copy; <?php echo e(date('Y')); ?> MyVcard MyPredict. Tous droits réservés. <span class="text-muted">v<?php echo e($appVersion); ?></span></p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="<?php echo e(route('terms')); ?>" class="text-decoration-none me-3">Conditions d'utilisation</a>
                    <a href="<?php echo e(route('privacy')); ?>" class="text-decoration-none">Politique de confidentialité</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- TinyMCE est chargé dans le fichier partials/tinymce.blade.php -->
    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH R:\Adev\200  -  test\projet_laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>