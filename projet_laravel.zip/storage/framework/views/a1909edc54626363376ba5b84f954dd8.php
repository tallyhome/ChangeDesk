<?php $__env->startSection('title', 'Gestion des fonctionnalités à venir'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Gestion des fonctionnalités à venir</h1>
                <a href="<?php echo e(route('admin.todolist.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Ajouter une fonctionnalité
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <?php if($todoItems->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Titre</th>
                                        <th>Description</th>
                                        <th>Progression</th>
                                        <th>Statut</th>
                                        <th>Date prévue</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $todoItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->title); ?></td>
                                            <td><?php echo Str::limit($item->description, 100); ?></td>
                                            <td style="width: 200px;">
                                                <div class="progress">
                                                    <div class="progress-bar bg-<?php echo e($item->color); ?>" role="progressbar" style="width: <?php echo e($item->progress); ?>%" aria-valuenow="<?php echo e($item->progress); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e($item->progress); ?>%</div>
                                                </div>
                                            </td>
                                            <td>
                                                <?php if($item->status == 'pending'): ?>
                                                    <span class="badge bg-warning">En attente</span>
                                                <?php elseif($item->status == 'in_progress'): ?>
                                                    <span class="badge bg-info">En cours</span>
                                                <?php elseif($item->status == 'completed'): ?>
                                                    <span class="badge bg-success">Terminé</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->expected_date ? $item->expected_date->format('d/m/Y') : 'Non définie'); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.todolist.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('admin.todolist.destroy', $item->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette fonctionnalité ?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-center">Aucune fonctionnalité à venir n'a été ajoutée.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Adev\200  -  test\ChanLog-1.0-main\resources\views/admin/todolist/index.blade.php ENDPATH**/ ?>