<?php $__env->startSection('title', 'Fonctionnalités à venir'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1 class="mb-4">Fonctionnalités à venir</h1>
    
    <div class="row">
        <?php $__currentLoopData = $todoItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($item->title); ?></h5>
                        <div class="card-text"><?php echo $item->description; ?></div>
                        
                        <!-- Barre de progression -->
                        <div class="progress mb-3">
                            <div class="progress-bar bg-<?php echo e($item->color ?? 'primary'); ?>" role="progressbar" 
                                style="width: <?php echo e($item->progress ?? 0); ?>%" 
                                aria-valuenow="<?php echo e($item->progress ?? 0); ?>" 
                                aria-valuemin="0" 
                                aria-valuemax="100"><?php echo e($item->progress ?? 0); ?>%</div>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <div>
                                <i class="fas fa-calendar-alt"></i> Date estimée : 
                                <?php if(is_string($item->expected_date)): ?>
                                    <?php echo e($item->expected_date); ?>

                                <?php elseif($item->expected_date): ?>
                                    <?php echo e($item->expected_date->format('d/m/Y')); ?>

                                <?php else: ?>
                                    Non définie
                                <?php endif; ?>
                            </div>
                            <div>
                                <?php if($item->status == 'pending'): ?>
                                    <span class="badge bg-warning">En attente</span>
                                <?php elseif($item->status == 'in_progress'): ?>
                                    <span class="badge bg-info">En cours</span>
                                <?php elseif($item->status == 'completed'): ?>
                                    <span class="badge bg-success">Terminé</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e($item->status); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Adev\200  -  test\ChanLog-1.0-main\resources\views/pages/todolist.blade.php ENDPATH**/ ?>