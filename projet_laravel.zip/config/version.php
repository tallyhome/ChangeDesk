<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Application Version
    |--------------------------------------------------------------------------
    |
    | This value is the version of your application. This value is used when
    | the application needs to place the application's version in a notification
    | or any other location as required by the application.
    |
    */

    'number' => '1.0.1',
];