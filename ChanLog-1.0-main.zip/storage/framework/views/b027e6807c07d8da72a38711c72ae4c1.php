<?php $__env->startSection('title', 'Historique des versions'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        <div class="col-md-8">
            <h1 class="mb-4">Historique des versions</h1>
            
            <?php $__currentLoopData = $versions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h2 class="h4 mb-0">v<?php echo e($version->version_number); ?> <small class="text-muted">(<?php echo e($version->release_date->format('d/m/Y')); ?>)</small></h2>
                    </div>
                    <div class="card-body">
                        <?php echo $version->content; ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="col-md-4">
            <div class="card sticky-top" style="top: 20px;">
                <div class="card-header">
                    <h5>Versions disponibles</h5>
                </div>
                <div class="card-body" style="max-height: 600px; overflow-y: auto;">
                    <ul class="list-group">
                        <?php $__currentLoopData = $versions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <a href="#version-<?php echo e($version->id); ?>" class="d-flex justify-content-between align-items-center text-decoration-none">
                                    <div>
                                        <strong>v<?php echo e($version->version_number); ?></strong>
                                        <br>
                                        <small><?php echo e($version->release_date->format('d/m/Y')); ?></small>
                                    </div>
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Ajouter des IDs aux éléments de version pour le défilement
    document.addEventListener('DOMContentLoaded', function() {
        const versionCards = document.querySelectorAll('.card.mb-4');
        versionCards.forEach((card, index) => {
            const version = <?php echo e($versions->pluck('id')->toJson()); ?>[index];
            card.id = 'version-' + version;
        });
        
        // Défilement fluide pour les liens d'ancrage
        document.querySelectorAll('a[href^="#version-"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Adev\200  -  test\ChanLog-1.0-main\resources\views/pages/changelog.blade.php ENDPATH**/ ?>