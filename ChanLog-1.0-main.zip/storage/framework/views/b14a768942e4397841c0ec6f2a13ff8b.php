<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Accueil</div>
                <div class="card-body">
                    <?php if(isset($page) && $page): ?>
                        <?php echo $page->content; ?>

                    <?php else: ?>
                        <p>Bienvenue sur notre site.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Adev\200  -  test\ChanLog-1.0-main\resources\views/pages/home.blade.php ENDPATH**/ ?>