<?php $__env->startSection('title', 'Gestion des rapports de bugs'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Gestion des rapports de bugs</h1>
                <a href="<?php echo e(route('admin.bug_reports.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Ajouter un rapport de bug
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <?php if($bugReports->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Titre</th>
                                        <th>Description</th>
                                        <th>Progression</th>
                                        <th>Sévérité</th>
                                        <th>Statut</th>
                                        <th>Date prévue</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $bugReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($bug->title); ?></td>
                                            <td><?php echo Str::limit($bug->description, 100); ?></td>
                                            <td style="width: 200px;">
                                                <div class="progress">
                                                    <div class="progress-bar bg-<?php echo e($bug->color); ?>" role="progressbar" style="width: <?php echo e($bug->progress); ?>%" aria-valuenow="<?php echo e($bug->progress); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e($bug->progress); ?>%</div>
                                                </div>
                                            </td>
                                            <td>
                                                <?php if($bug->severity == 'low'): ?>
                                                    <span class="badge bg-success">Faible</span>
                                                <?php elseif($bug->severity == 'medium'): ?>
                                                    <span class="badge bg-warning">Moyenne</span>
                                                <?php elseif($bug->severity == 'high'): ?>
                                                    <span class="badge bg-danger">Élevée</span>
                                                <?php elseif($bug->severity == 'critical'): ?>
                                                    <span class="badge bg-dark">Critique</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($bug->status == 'open'): ?>
                                                    <span class="badge bg-danger">Ouvert</span>
                                                <?php elseif($bug->status == 'in_progress'): ?>
                                                    <span class="badge bg-info">En cours</span>
                                                <?php elseif($bug->status == 'resolved'): ?>
                                                    <span class="badge bg-success">Résolu</span>
                                                <?php elseif($bug->status == 'closed'): ?>
                                                    <span class="badge bg-secondary">Fermé</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($bug->expected_fix_date ? $bug->expected_fix_date->format('d/m/Y') : 'Non définie'); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.bug_reports.edit', $bug->id)); ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('admin.bug_reports.destroy', $bug->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce rapport de bug ?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-center">Aucun rapport de bug n'a été ajouté.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Adev\200  -  test\ChanLog-1.0-main\resources\views/admin/bug_reports/index.blade.php ENDPATH**/ ?>